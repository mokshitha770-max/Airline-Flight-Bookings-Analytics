# Airline Flight Operations Analytics Platform

A Databricks Lakeflow Spark Declarative Pipelines project using the Medallion Architecture (Bronze → Silver → Gold) for a synthetic Indian domestic-airline dataset.

## Project structure

```text
airline-flight-operations-analytics/
├── README.md
├── .gitignore
├── src/
│   └── airline_flights_pipeline.sql
├── data/
│   └── README.md
├── powerbi/
│   └── README.md
└── screenshots/
    └── README.md
```

## 1. Dataset

The expected input file is `airline_flights_raw.csv` (1,365 synthetic rows, 20 columns).

The dataset itself was not attached to the project request. Download the CSV from your course/project source and upload it to this Unity Catalog Volume:

`/Volumes/aviation_catalog/flights/raw_files/`

Do not commit private or restricted data to GitHub. This project dataset is described as synthetic, but verify its license/instructions before publishing it.

## 2. Databricks setup

Run the following in a Databricks SQL editor (use a catalog/schema where you have permission):

```sql
CREATE CATALOG IF NOT EXISTS aviation_catalog;
CREATE SCHEMA IF NOT EXISTS aviation_catalog.flights;
CREATE VOLUME IF NOT EXISTS aviation_catalog.flights.raw_files;
```

Upload `airline_flights_raw.csv` to the `raw_files` Volume.

In Databricks, create a **Lakeflow Spark Declarative Pipeline**:
- Default catalog: `aviation_catalog`
- Default schema: `flights`
- Add `src/airline_flights_pipeline.sql` as a pipeline SQL source
- Start the pipeline and inspect the event log and graph

The SQL uses `read_files` with CSV schema inference. If your workspace policy requires an explicit schema, define it in the `read_files` options based on the supplied CSV.

## 3. Medallion layers

| Layer | Object | Purpose |
|---|---|---|
| Bronze | `bronze_airline_flights` | Raw CSV records plus source filename and ingestion timestamp |
| Silver | `silver_flights_clean` | Deduplicated, normalized, business-valid flights |
| Silver | `silver_flights_rejected` | Deduplicated records rejected for impossible passenger/fare values |
| Gold | `gold_monthly_flights` | Monthly operational and financial trends |
| Gold | `gold_airline_summary` | Airline-level performance |
| Gold | `gold_route_summary` | Origin/destination performance |
| Gold | `gold_delay_summary` | Delay category and reason analysis |
| Gold | `gold_data_quality` | Issue counts and reconciliation |

## 4. Cleaning rules

- Deduplicate on `flight_id` (not `flight_number`).
- Trim and title-case airline, city, aircraft and reason text.
- Replace missing airline and delay reason with `Unknown`.
- Calculate missing delay minutes from scheduled and actual departure timestamps.
- Calculate missing ticket revenue as `passengers * avg_fare`.
- Keep early departures (negative delay minutes); they are On Time.
- Reject records with passengers below zero, passengers above seat capacity, or negative average fare.
- Keep missing aircraft IDs; they do not invalidate the flight.

The pipeline keeps one record per `flight_id` before splitting valid and rejected flights, so duplicates are not double-counted in either Silver table.

## 5. Reconciliation

`gold_data_quality` exposes:
- Bronze rows
- Duplicate rows removed
- Clean rows
- Rejected rows
- `reconciliation_passed`

Expected check:

`bronze_rows = clean_rows + rejected_rows + duplicate_rows`

The case study's expected clean count (1,321) is a reference result, not hard-coded. Actual results depend on the exact CSV supplied.

## 6. Dashboard

Choose **one** dashboard tool:
- Databricks AI/BI, or
- Power BI (see [`powerbi/README.md`](powerbi/README.md))

Build the three requested pages:
1. Overview
2. Airlines, Routes & Delays
3. Data Quality

Use only the Gold tables for dashboard visuals.

## 7. Suggested validation queries

```sql
SELECT COUNT(*) FROM aviation_catalog.flights.bronze_airline_flights;
SELECT COUNT(*) FROM aviation_catalog.flights.silver_flights_clean;
SELECT COUNT(*) FROM aviation_catalog.flights.silver_flights_rejected;
SELECT * FROM aviation_catalog.flights.gold_data_quality;
```

Check that every clean flight has a delay category:

```sql
SELECT delay_category, COUNT(*)
FROM aviation_catalog.flights.silver_flights_clean
GROUP BY delay_category;
```

Check uniqueness:

```sql
SELECT flight_id, COUNT(*)
FROM aviation_catalog.flights.silver_flights_clean
GROUP BY flight_id
HAVING COUNT(*) > 1;
```

## 8. Known assumptions

- CSV columns match the names in the project brief.
- `flight_id` is populated for source records.
- CSV values can be parsed into the expected numeric/date/timestamp types.
- The pipeline is a batch-file learning project; it is not a live flight-tracking system.
- Reconciliation treats one row per distinct `flight_id` as the candidate flight population.

## 9. Repository publication

Create a new GitHub repository named `airline-flight-operations-analytics`, then upload the contents of this folder. Keep the downloaded ZIP and the extracted folder together locally. See GitHub's web upload flow or use Git:

```bash
git init
git add .
git commit -m "Add airline flight analytics Lakeflow pipeline"
git branch -M main
git remote add origin https://github.com/<your-username>/airline-flight-operations-analytics.git
git push -u origin main
```

Replace `<your-username>` with your GitHub username.
