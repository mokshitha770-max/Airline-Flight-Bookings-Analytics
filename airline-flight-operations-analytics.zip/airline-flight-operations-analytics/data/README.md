# Dataset location

Place the course-provided `airline_flights_raw.csv` here for local reference, or upload it directly to the Databricks Unity Catalog Volume:

`/Volumes/aviation_catalog/flights/raw_files/`

The CSV was not included in the request, so no fabricated dataset is provided. Confirm permission/licensing before committing the source CSV to a public GitHub repository.
