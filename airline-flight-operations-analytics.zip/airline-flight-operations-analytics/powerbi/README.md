# Power BI dashboard guide

Connect Power BI Desktop to the Databricks SQL Warehouse using **Get Data → Azure Databricks**. Select/import these Gold tables from `aviation_catalog.flights`:

- `gold_monthly_flights`
- `gold_airline_summary`
- `gold_route_summary`
- `gold_delay_summary`
- `gold_data_quality`

## Page 1 — Overview
- KPI cards: Total Flights, Passengers, Ticket Revenue, Delayed Flights
- Line chart: `flight_month` vs `ticket_revenue`
- Bar chart: `airline` vs `on_time_pct`

## Page 2 — Airlines, Routes & Delays
- Airline table: flights, load factor, on-time %, average delay
- Top 10 route bar chart: origin + destination vs ticket revenue
- Delay category chart: delay category vs flights
- Delay reason chart: delay reason vs flights

## Page 3 — Data Quality
- KPI cards: Bronze rows, clean rows, rejected rows, duplicate rows
- Reconciliation status from `reconciliation_passed`
- Bar chart using the problem-count columns in `gold_data_quality`

**Important:** Do not sum or average already-aggregated percentages such as `load_factor_pct` or `on_time_pct`. Use the value at its intended grouping level.
