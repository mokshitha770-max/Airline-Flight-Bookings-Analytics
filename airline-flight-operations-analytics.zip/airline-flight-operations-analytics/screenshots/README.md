# Screenshots

Add your own screenshots after running the project:

1. Databricks pipeline graph
2. Gold table previews
3. Dashboard Overview page
4. Dashboard Airlines, Routes & Delays page
5. Dashboard Data Quality page

No screenshots are included because the pipeline has not been run in your Databricks workspace.
