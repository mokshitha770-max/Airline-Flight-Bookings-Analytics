-- Airline Flight Operations Analytics
-- Lakeflow Spark Declarative Pipelines SQL
-- Default catalog/schema: aviation_catalog.flights
--
-- Input: /Volumes/aviation_catalog/flights/raw_files/airline_flights_raw.csv
-- This pipeline intentionally separates deduplication from validity checks.

CREATE OR REFRESH STREAMING TABLE bronze_airline_flights AS
SELECT
  *,
  _metadata.file_name AS source_file,
  current_timestamp() AS loaded_at
FROM STREAM read_files(
  '/Volumes/aviation_catalog/flights/raw_files/',
  format => 'csv',
  header => true,
  inferSchema => true
);

-- Keep exactly one source record for each flight_id before splitting clean/rejected.
-- A stable preference for the first loaded row is used where duplicate records differ.
CREATE OR REFRESH MATERIALIZED VIEW silver_flights_deduplicated AS
SELECT * EXCEPT (row_num)
FROM (
  SELECT
    *,
    ROW_NUMBER() OVER (
      PARTITION BY flight_id
      ORDER BY loaded_at, source_file
    ) AS row_num
  FROM bronze_airline_flights
  WHERE flight_id IS NOT NULL
)
WHERE row_num = 1;

CREATE OR REFRESH MATERIALIZED VIEW silver_flights_clean AS
WITH normalized AS (
  SELECT
    TRIM(CAST(flight_id AS STRING)) AS flight_id,
    TRIM(CAST(flight_number AS STRING)) AS flight_number,
    COALESCE(NULLIF(INITCAP(TRIM(CAST(airline AS STRING))), ''), 'Unknown') AS airline,
    COALESCE(NULLIF(UPPER(TRIM(CAST(aircraft_id AS STRING))), ''), 'Unknown') AS aircraft_id,
    INITCAP(TRIM(CAST(aircraft_type AS STRING))) AS aircraft_type,
    TO_DATE(flight_date) AS flight_date,
    INITCAP(TRIM(CAST(day_of_week AS STRING))) AS day_of_week,
    INITCAP(TRIM(CAST(origin_city AS STRING))) AS origin_city,
    INITCAP(TRIM(CAST(destination_city AS STRING))) AS destination_city,
    INITCAP(TRIM(CAST(origin_region AS STRING))) AS origin_region,
    CAST(distance_km AS DOUBLE) AS distance_km,
    CAST(scheduled_departure AS TIMESTAMP) AS scheduled_departure,
    CAST(actual_departure AS TIMESTAMP) AS actual_departure,
    COALESCE(
      CAST(delay_minutes AS INT),
      TIMESTAMPDIFF(
        MINUTE,
        CAST(scheduled_departure AS TIMESTAMP),
        CAST(actual_departure AS TIMESTAMP)
      )
    ) AS delay_minutes,
    COALESCE(NULLIF(INITCAP(TRIM(CAST(delay_reason AS STRING))), ''), 'Unknown') AS delay_reason,
    CAST(seat_capacity AS INT) AS seat_capacity,
    CAST(passengers AS INT) AS passengers,
    CAST(avg_fare AS DECIMAL(18,2)) AS avg_fare,
    COALESCE(
      CAST(ticket_revenue AS DECIMAL(20,2)),
      CAST(passengers AS DECIMAL(18,2)) * CAST(avg_fare AS DECIMAL(18,2))
    ) AS ticket_revenue,
    CAST(fuel_cost AS DECIMAL(20,2)) AS fuel_cost,
    source_file,
    loaded_at
  FROM silver_flights_deduplicated
),
classified AS (
  SELECT
    *,
    CASE
      WHEN delay_minutes <= 15 THEN 'On Time'
      WHEN delay_minutes <= 60 THEN 'Minor Delay'
      ELSE 'Major Delay'
    END AS delay_category
  FROM normalized
)
SELECT *
FROM classified
WHERE passengers >= 0
  AND passengers <= seat_capacity
  AND avg_fare >= 0;

CREATE OR REFRESH MATERIALIZED VIEW silver_flights_rejected AS
WITH normalized_for_rejection AS (
  SELECT
    *,
    CAST(passengers AS INT) AS passengers_num,
    CAST(seat_capacity AS INT) AS seat_capacity_num,
    CAST(avg_fare AS DECIMAL(18,2)) AS avg_fare_num
  FROM silver_flights_deduplicated
)
SELECT
  *,
  CASE
    WHEN passengers_num < 0 THEN 'Negative passenger count'
    WHEN passengers_num > seat_capacity_num THEN 'Passengers more than seats'
    WHEN avg_fare_num < 0 THEN 'Average fare is negative'
    ELSE 'Other invalid record'
  END AS reject_reason
FROM normalized_for_rejection
WHERE passengers_num < 0
   OR passengers_num > seat_capacity_num
   OR avg_fare_num < 0;

-- GOLD: monthly operations and financial performance.
CREATE OR REFRESH MATERIALIZED VIEW gold_monthly_flights AS
SELECT
  DATE_TRUNC('MONTH', flight_date) AS flight_month,
  COUNT(*) AS flights,
  SUM(passengers) AS passengers,
  SUM(seat_capacity) AS seats,
  ROUND(100.0 * SUM(passengers) / NULLIF(SUM(seat_capacity), 0), 1) AS load_factor_pct,
  SUM(ticket_revenue) AS ticket_revenue,
  SUM(fuel_cost) AS fuel_cost,
  SUM(CASE WHEN delay_category <> 'On Time' THEN 1 ELSE 0 END) AS delayed_flights
FROM silver_flights_clean
GROUP BY DATE_TRUNC('MONTH', flight_date);

-- GOLD: airline performance.
CREATE OR REFRESH MATERIALIZED VIEW gold_airline_summary AS
SELECT
  airline,
  COUNT(*) AS flights,
  SUM(passengers) AS passengers,
  SUM(seat_capacity) AS seats,
  SUM(ticket_revenue) AS ticket_revenue,
  ROUND(100.0 * SUM(passengers) / NULLIF(SUM(seat_capacity), 0), 1) AS load_factor_pct,
  ROUND(
    100.0 * SUM(CASE WHEN delay_category = 'On Time' THEN 1 ELSE 0 END) / COUNT(*),
    1
  ) AS on_time_pct,
  ROUND(AVG(delay_minutes), 1) AS avg_delay_minutes
FROM silver_flights_clean
GROUP BY airline;

-- GOLD: route performance.
CREATE OR REFRESH MATERIALIZED VIEW gold_route_summary AS
SELECT
  origin_city,
  destination_city,
  COUNT(*) AS flights,
  SUM(passengers) AS passengers,
  SUM(seat_capacity) AS seats,
  SUM(ticket_revenue) AS ticket_revenue,
  ROUND(100.0 * SUM(passengers) / NULLIF(SUM(seat_capacity), 0), 1) AS load_factor_pct
FROM silver_flights_clean
GROUP BY origin_city, destination_city;

-- GOLD: delay category and reason.
CREATE OR REFRESH MATERIALIZED VIEW gold_delay_summary AS
SELECT
  delay_category,
  delay_reason,
  COUNT(*) AS flights,
  ROUND(AVG(delay_minutes), 1) AS avg_delay_minutes
FROM silver_flights_clean
GROUP BY delay_category, delay_reason;

-- GOLD: quality counts and row-accounting reconciliation.
CREATE OR REFRESH MATERIALIZED VIEW gold_data_quality AS
WITH bronze_stats AS (
  SELECT
    COUNT(*) AS bronze_rows,
    COUNT(*) - COUNT(DISTINCT flight_id) AS duplicate_rows,
    SUM(CASE WHEN airline IS NULL OR TRIM(CAST(airline AS STRING)) = '' THEN 1 ELSE 0 END) AS missing_airline_rows,
    SUM(CASE WHEN delay_minutes IS NULL THEN 1 ELSE 0 END) AS missing_delay_minutes_rows,
    SUM(CASE WHEN delay_reason IS NULL OR TRIM(CAST(delay_reason AS STRING)) = '' THEN 1 ELSE 0 END) AS missing_delay_reason_rows,
    SUM(CASE WHEN aircraft_id IS NULL OR TRIM(CAST(aircraft_id AS STRING)) = '' THEN 1 ELSE 0 END) AS missing_aircraft_id_rows,
    SUM(CASE WHEN ticket_revenue IS NULL THEN 1 ELSE 0 END) AS missing_ticket_revenue_rows,
    SUM(CASE WHEN CAST(passengers AS INT) > CAST(seat_capacity AS INT) THEN 1 ELSE 0 END) AS overbooked_rows,
    SUM(CASE WHEN CAST(passengers AS INT) < 0 THEN 1 ELSE 0 END) AS negative_passenger_rows,
    SUM(CASE WHEN CAST(avg_fare AS DECIMAL(18,2)) < 0 THEN 1 ELSE 0 END) AS negative_fare_rows
  FROM bronze_airline_flights
),
silver_stats AS (
  SELECT COUNT(*) AS clean_rows FROM silver_flights_clean
),
rejected_stats AS (
  SELECT COUNT(*) AS rejected_rows FROM silver_flights_rejected
)
SELECT
  b.*,
  s.clean_rows,
  r.rejected_rows,
  (b.bronze_rows = s.clean_rows + r.rejected_rows + b.duplicate_rows) AS reconciliation_passed
FROM bronze_stats b
CROSS JOIN silver_stats s
CROSS JOIN rejected_stats r;
